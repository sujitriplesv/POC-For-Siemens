﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.FileProviders;
using POC_MailServiceWebApplication.ApiClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace POC_MailServiceWebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DownloadController : ControllerBase
    {     
         private string fileName { get; set; }

        readonly MailHttpClient _httpClient;

        private IWebHostEnvironment _hostingEnvironment; 
        public DownloadController(MailHttpClient client, IWebHostEnvironment environment)
        {
            _httpClient = client;
            _hostingEnvironment = environment;
        }  

        [HttpGet("DownloadFile")]
        public IActionResult DownloadFile()
        {
            //var attachmentfile = await _httpClient.GetAsync<DocumentViewModel>("Document/" + id);
            
            fileName = "Samplefile1.xlsx";
            var filePath = Path.Combine(_hostingEnvironment.WebRootPath);

            IFileProvider provider = new PhysicalFileProvider(filePath);
            IFileInfo fileInfo = provider.GetFileInfo(fileName);
            
            var readStream = fileInfo.CreateReadStream();             
            return File(readStream, "application/octet-stream", "Samplefile1.xlsx");

            //var mimeType = "application/vnd.ms-excel";
            //return File(readStream, mimeType, fileName);
        }

        //public async Task<ActionResult> DownloadDocument(int id)
        //{
        //    var attachmentfile = await _httpClient.GetAsync<DocumentViewModel>("Document/" + id);


        //        byte[] bytesToStream = Encoding.UTF8.GetBytes(documentViewModel.Data);
        //        var memoryStream = new MemoryStream(bytesToStream);
        //        return new FileStreamResult(memoryStream, documentViewModel.MimeType)
        //        {
        //            FileDownloadName = documentViewModel.DocumentName
        //        };


        //    return null;
        //}

    }
}
