﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace POC_MailServiceWebApplication.ApiClient
{
    public class MailHttpClient
    {
        private readonly HttpClient _httpClient;
        private Uri BaseEndpoint { get; set; }                
        public MailHttpClient(HttpClient client, IConfiguration configuration)
        {
            string configWebApiString = configuration["WebApiBaseUrl"];

            if (string.IsNullOrWhiteSpace(configWebApiString))
            {
                throw new ArgumentNullException("WebApiBaseUrl");
            }

            BaseEndpoint = new Uri(configWebApiString);

            _httpClient = new HttpClient
            {
                BaseAddress = BaseEndpoint
            };
           
        }

        private void AddHeaders()
        {
            //Add some default headers. Maybe auth token?             
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
        public async Task<T> GetAsync<T>(string requestUrl)
        {
            AddHeaders();
            var response = await _httpClient.GetAsync(requestUrl, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();
            var data = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(data);
        }
        
        public async Task<HttpResponseMessage> PostAsync<T>(string requestUrl, T content)
        {
            AddHeaders();

            var response = await _httpClient.PostAsJsonAsync<T>(requestUrl, content);
            response.EnsureSuccessStatusCode();
            var data = await response.Content.ReadAsStringAsync();
            return new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(data, Encoding.UTF8, "text/plain") };
            //return JsonConvert.DeserializeObject<HttpResponseMessage>(data);
        }
    }
}
