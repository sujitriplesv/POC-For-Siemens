﻿CREATE TABLE [dbo].[MailAttachment]
(
	[AttachmentId] INT IDENTITY (1, 1) NOT NULL , 
    [MailId] INT NOT NULL, 
    [FileName] NVARCHAR(250) NOT NULL,
    CONSTRAINT [PK_MailAttachment] PRIMARY KEY CLUSTERED ([AttachmentId]  ASC),
    CONSTRAINT [FK_MailAttachment_MailMessage] FOREIGN KEY ([MailId]) REFERENCES [dbo].[MailMessage] ([MailId]) 
    
)
