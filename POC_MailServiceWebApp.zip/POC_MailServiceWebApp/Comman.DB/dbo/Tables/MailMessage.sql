﻿CREATE TABLE [dbo].[MailMessage]
(
	[MailId] INT IDENTITY (1, 1) NOT NULL , 
    [Subject] NVARCHAR(500) NOT NULL, 
    [BodyContent] NVARCHAR(MAX) NOT NULL, 
    [IsAttachment] BIT NOT NULL, 
    CONSTRAINT [PK_MailMessage] PRIMARY KEY CLUSTERED ([MailId] ASC),
)
