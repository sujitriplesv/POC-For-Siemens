using System;

namespace POC_MailServiceWebApi
{
    public class MailService
    {
        public DateTime Date { get; set; }
        public string Subject { get; set; }
        public string BodyContent { get; set; }
        public string Attachments { get; set; }
    }
}
