﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using EmailService;
using Common.Data.Interface;
using EmailService.Models;

namespace POC_MailServiceWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MailServiceController : ControllerBase
    {
        private readonly IEmailReader _emailReader;
        private readonly IMailMessageService _mailMessage;
        public MailServiceController(IEmailReader emailReader)
        {
            _emailReader = emailReader;
            //_mailMessage = mailMessage;
        }              

        [HttpGet]
        public IEnumerable<MailService> Get()
        {
            _emailReader.ReadEmail();
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new MailService
            {
                Date = DateTime.Now.AddDays(index),
                Subject = "Test Subject" + rng.Next(1, 5),
                BodyContent = "Test body Content" ,                 
                Attachments ="test.txt"
            })
            .ToArray();
        }

        //[HttpPost]
        //public int Post(mailmessage)
        //{
        //    return _mailMessage.AddMailMessage(mailInfo);
        //}
    }
}
