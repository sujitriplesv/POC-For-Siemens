﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Common.Data.Entities
{
    public partial class MailMessage
    {
        public MailMessage()
        {              
            MailAttachment = new HashSet<MailAttachment>();
        }

        [Key]
        public int MailId { get; set; }
        public string Subject { get; set; }
        public string BodyContent { get; set; }
        public bool IsAttachment { get; set; }
        public ICollection<MailAttachment> MailAttachment { get; set; }

    }
}
