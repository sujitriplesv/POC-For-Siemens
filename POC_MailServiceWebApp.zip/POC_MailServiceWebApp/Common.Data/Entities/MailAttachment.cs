﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Common.Data.Entities
{
    public partial class MailAttachment
    {
        public MailAttachment()
        { }

        [Key]        
        public int AttachmentId { get; set; }

        public int MailId { get; set; }

        public string FileName { get; set; }
        public MailMessage MailMessage { get; set; }
    }
}
