﻿using Common.Data.DBContext;
using Common.Data.Entities;
using Common.Data.Interface;
using Common.Data.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Data
{
    public class UnitOfRepository: IUnitOfRepository
    {
        private readonly MailDBContext _dbcontext;
        private IRepository<MailMessage> _messageRepository;
        private IRepository<MailAttachment> _attachmentRepository;

        public UnitOfRepository( MailDBContext mailDBContext)
        {
            _dbcontext = mailDBContext;
            _messageRepository = new MailMessageRepository(_dbcontext);
            _attachmentRepository = new MailAttachmentRepository(_dbcontext);
        }

        public DbContext DbContext
        {
            get
            {
                return _dbcontext;
            }
        }
        public bool HasUnsavedChanges()
        {
            return _dbcontext.ChangeTracker.HasChanges();
        }
        public IRepository<MailMessage> MailMessageRepository
        {
            get
            {
                if (_messageRepository == null)
                    _messageRepository = new BaseRepository<MailMessage>(_dbcontext);

                return _messageRepository;
            }
        }           

        public IRepository<MailAttachment> MailAttachmentRepository
        {
            get
            {
                if (_attachmentRepository == null)
                    _attachmentRepository = new BaseRepository<MailAttachment>(_dbcontext);

                return _attachmentRepository;
            }
        }
        public int Save()
        {
            return _dbcontext.SaveChanges();
        }

        public void Dispose()
        {
            _dbcontext.Dispose();
        }

        
    }
}
