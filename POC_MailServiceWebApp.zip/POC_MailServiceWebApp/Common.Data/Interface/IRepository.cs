﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Common.Data.Interface
{
    public interface IRepository<TEntity> where TEntity : new()
    {
        TEntity Get(object id);
        IQueryable<TEntity> All();
        IQueryable<TEntity> Find(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = "");
        TEntity Add(TEntity t);
        void AddRange(IEnumerable<TEntity> entities);
        void Update(TEntity t);
        void Delete(TEntity t);
        void DeleteAll(IEnumerable<TEntity> t);
        void Delete(object id);
        DataSet ExecuteDataSet(string query, params SqlParameter[] param);
        DataSet ExecuteQuery(string connectionString, CommandType type, string query, params SqlParameter[] param);
        DataSet ExecuteQuery(CommandType type, string query, params SqlParameter[] param);
        object ExecuteScalar(string connectionString, CommandType type, string query, params SqlParameter[] param);
        int ExecuteSqlCommand(string sql, params SqlParameter[] parameters);

    }
}
