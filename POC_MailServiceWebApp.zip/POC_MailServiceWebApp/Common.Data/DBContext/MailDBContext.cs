﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Common.Data.Entities;

namespace Common.Data.DBContext
{
    public partial class MailDBContext : DbContext
    {          
        public MailDBContext ()
        {}
        public MailDBContext(DbContextOptions<MailDBContext> options): base (options)
        {}
        public DbSet<MailMessage> MailMessage { get; set; }
        public DbSet<MailAttachment> MailAttachment { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //if (!optionsBuilder.IsConfigured)
            //{
            //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
            //   optionsBuilder.UseSqlServer("Server=xxx;Initial Catalog=Testdb;Persist Security Info=False;User ID=sa;Password=pwd@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            //}

            optionsBuilder.UseSqlite("Filename=Data.db");
        }
        public static void InitDatabase()
        {
            var context = new MailDBContext();
            context.Database.EnsureCreated();
            context.Database.EnsureDeleted();
            SeedData(context);
        }
        private static void SeedData(MailDBContext context)
         {
            var transaction = context.Database.BeginTransaction();

            AddMailMessage(context);
            AddMailAttachment(context);
            context.SaveChanges();

            transaction.Commit();

         }

        private static void AddMailMessage( MailDBContext context)
        {
            context.MailMessage.Add(new Entities.MailMessage
            {
                MailId = 101,
                Subject = "POC Mail service Implementation 1",
                BodyContent = "Test mail with Attached file 1",
                IsAttachment = true
            });
            context.MailMessage.Add(new Entities.MailMessage
            {
                MailId = 102,
                Subject = "POC Mail service Implementation 2",
                BodyContent = "Test mail with Attached file 2",
                IsAttachment = true
            });
            context.SaveChanges();

        }

        private static void AddMailAttachment(MailDBContext context)
        {             
            context.MailAttachment.Add(new Entities.MailAttachment
            {
                AttachmentId = 1,
                MailId = 101,
                FileName = "Samplefile1.xls"
            });
            context.MailAttachment.Add(new Entities.MailAttachment
            {
                AttachmentId = 2,
                MailId = 101,
                FileName = "Samplefile2.txt"
            });

            context.MailAttachment.Add(new Entities.MailAttachment
            {
                AttachmentId = 3,
                MailId = 102,
                FileName = "Samplefile1.pdf"
            });
            context.SaveChanges();

        }
    }
}
