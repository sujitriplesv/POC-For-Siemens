﻿using Common.Data.Entities;
using Common.Data.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Data.Repository
{
    public class MailMessageRepository : BaseRepository<MailMessage>
	{
		public MailMessageRepository(DbContext dbContext) : base(dbContext)
		{
		}
	}
}

