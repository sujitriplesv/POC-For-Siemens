﻿using Common.Data.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;

namespace Common.Data.Repository
{
    public class BaseRepository<TEntity> : IDisposable, IRepository<TEntity> where TEntity : class, new()
    {
        protected DbContext _context;
        private DbSet<TEntity> _dbset;
        private static int _commandTimeOut = 30;

        public BaseRepository(DbContext dbContext)
        {
            _context = dbContext;
            _dbset = dbContext.Set<TEntity>();
        }

        internal static int CommandTimeout
        {
            get
            {
                return _commandTimeOut;
            }
            set
            {
                _commandTimeOut = value;
            }
        }

        public virtual TEntity Add(TEntity entity)
        {
            _dbset.Add(entity);

            return entity;
        }

        public void AddRange(IEnumerable<TEntity> entities)
        {
            _context.Set<TEntity>().AddRange(entities);
        }

        public virtual void Update(TEntity t)
        {
            if (t == null)
                throw new ArgumentNullException(string.Format("Entity: {0}", typeof(TEntity)));

            _dbset.Attach(t);
            _context.Entry(t).State = EntityState.Modified;
        }

        public void Delete(TEntity t)
        {
            if (t == null)
                throw new ArgumentNullException(string.Format("Entity: {0}", typeof(TEntity)));

            if (_context.Entry(t).State == EntityState.Detached)
                _dbset.Attach(t);
            _dbset.Remove(t);

        }

        public void DeleteAll(IEnumerable<TEntity> t)
        {
            if (t == null)
                throw new ArgumentNullException(string.Format("Entity: {0}", typeof(TEntity)));

            while (t.Count() > 0)
            {
                Delete(t.ElementAt(0));
            }
        }

        public virtual void Delete(object id)
        {
            TEntity t = Get(id);
            Delete(t);
        }

        public virtual IQueryable<TEntity> All()
        {
            return _dbset;
        }

        public virtual TEntity Get(object id)
        {
            return _dbset.Find(id);
        }

        public virtual IQueryable<TEntity> Find(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = "")
        {
            IQueryable<TEntity> query = _dbset;
            if (filter != null)
            {
                query = query.Where(filter);
            }
            if (!string.IsNullOrEmpty(includeProperties))
            {
                foreach (var includeProperty in includeProperties.Split
                    (new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            if (orderBy != null)
            {
                query = orderBy(query);
            }
            return query;
        }

        [Obsolete]
        public int ExecuteSqlCommand(string sql, params SqlParameter[] parameters)
        {
            return _context.Database.ExecuteSqlCommand(sql, parameters);
        }
        public DataSet ExecuteDataSet(string query, params SqlParameter[] param)
        {
            var closeConnection = false;
            var connection = _context.Database.GetDbConnection() as SqlConnection;
            try
            {
                if (connection.State != ConnectionState.Open)
                {
                    closeConnection = true;
                    connection.Open();
                }
                return ExecuteQuery(connection, CommandType.StoredProcedure, query, param);
            }
            finally
            {
                if (closeConnection && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private DataSet ExecuteQuery(SqlConnection connection, CommandType type, string query, SqlParameter[] param)
        {
            SqlCommand command = connection.CreateCommand();
            command.CommandTimeout = _commandTimeOut;
            command.CommandText = query;
            command.CommandType = type;
            if (param != null)
                command.Parameters.AddRange(param);

            using (SqlDataAdapter da = new SqlDataAdapter())
            {
                da.SelectCommand = command;
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        public object ExecuteScalar(string connectionString, CommandType type, string query, params SqlParameter[] param)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    SqlCommand cmd = connection.CreateCommand();
                    cmd.CommandTimeout = _commandTimeOut;
                    cmd.CommandType = type;
                    cmd.CommandText = query;

                    if (param != null)
                        cmd.Parameters.AddRange(param);
                    return cmd.ExecuteScalar();

                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public int ExecuteNonQuery(CommandType type, string query, params SqlParameter[] param)
        {
            var connection = _context.Database.GetDbConnection() as SqlConnection;
            var closeConnection = false;
            try
            {
                if (connection.State != ConnectionState.Open)
                {
                    closeConnection = true;
                    connection.Open();
                }
                SqlCommand command = connection.CreateCommand();
                command.CommandTimeout = _commandTimeOut;
                command.CommandText = query;
                command.CommandType = type;
                if (param != null)
                    command.Parameters.AddRange(param);

                return command.ExecuteNonQuery();
            }
            finally
            {
                if (closeConnection && connection.State == ConnectionState.Open)
                    connection.Close();
            }

        }

        public DataSet ExecuteQuery(CommandType type, string query, params SqlParameter[] param)
        {
            var connection = _context.Database.GetDbConnection() as SqlConnection;
            var closeConnection = false;
            try
            {
                if (connection.State != ConnectionState.Open)
                {
                    closeConnection = true;
                    connection.Open();
                }
                var ds = ExecuteQuery(connection, type, query, param);
                return ds;
            }
            finally
            {
                if (closeConnection && connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        public DataSet ExecuteQuery(string connectionString, CommandType type, string query, params SqlParameter[] param)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    var ds = ExecuteQuery(connection, type, query, param);
                    return ds;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        #region Dispose
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                    _context = null;
                }
            }
            this.disposed = true;
        }
        #endregion
    }
}
