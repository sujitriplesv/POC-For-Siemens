﻿using Common.Data.Entities;
using Common.Data.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Data
{
    public interface IUnitOfRepository : IDisposable
    {
        IRepository<MailMessage> MailMessageRepository { get; }
        IRepository<MailAttachment> MailAttachmentRepository { get; }
        int Save();
    }
}
