﻿using System;

namespace EmailService
{      
    public class EmailConfiguration
    {
        public string From { get; set; }
        public string SmtpServer { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FromAddress { get; set; }
        public string ToAddress { get; set; }
        public string ReadMailBoxAddress { get; set; }
        public string ExchangeUrl { get; set; }
        public string AttachmentPath { get; set; }
       
    }
}
