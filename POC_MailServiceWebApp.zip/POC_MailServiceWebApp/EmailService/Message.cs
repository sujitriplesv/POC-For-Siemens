﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using MimeKit;
using System.Linq;


namespace EmailService
{
    public class Message
    {
        public List<MailboxAddress> From { get; set; }

        //public List<MailboxAddress> To { get; set; }           
        public string Subject { get; set; }
        public string Content { get; set; }
        public IFormFileCollection Attachments { get; set; }

        [Obsolete]
        public Message(IEnumerable<string> from, string subject, string content)
        {
            //To = new List<MailboxAddress>();
            //To.AddRange(to.Select(x => new MailboxAddress(x)));

            From = new List<MailboxAddress>();
            From.AddRange(from.Select(x => new MailboxAddress(x)));
            Subject = subject;
            Content = content;
        }
        
    }
}
