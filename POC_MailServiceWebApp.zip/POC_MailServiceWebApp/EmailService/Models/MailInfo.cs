﻿using System;
using System.Collections.Generic;
using System.Text;
using Common.Data.Entities;

namespace EmailService.Models
{
    public class MailInfo
    {
        public MailInfo() { }
        public MailInfo(Common.Data.Entities.MailMessage message)
        {
            MailId = message.MailId;
            Subject = message.Subject;
            BodyContent = message.BodyContent;
            IsAttachment = message.IsAttachment;
            if (IsAttachment)
            {
                if (message.MailAttachment.Count > 0)
                {
                    AttachmentInfos = new List<AttachmentInfo>();

                    foreach (var file in message.MailAttachment)
                    {
                        AttachmentInfos.Add(new AttachmentInfo(file));
                    }
                }
            }                  
        }
        public int MailId { get; set; }
        public string Subject { get; set; }
        public string BodyContent { get; set; }
        public bool IsAttachment { get; set; }
        public List<AttachmentInfo> AttachmentInfos { get; set; }       
    }
}
