﻿using System;
using System.Collections.Generic;
using System.Text;
using Common.Data.Entities;

namespace EmailService.Models
{
    public class AttachmentInfo
    {
        public AttachmentInfo()
        {

        }
        public AttachmentInfo(Common.Data.Entities.MailAttachment attachment)
        {
            AttachmentId = (int)attachment.AttachmentId;
            MailId = (int)attachment.MailId;
            FileName = attachment.FileName;
        }
        public int AttachmentId { get; set; }
        public int MailId { get; set; }
        public string FileName { get; set; }           
    }
}
