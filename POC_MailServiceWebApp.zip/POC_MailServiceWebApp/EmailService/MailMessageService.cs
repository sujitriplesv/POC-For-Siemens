﻿using Common.Data;
using Common.Data.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Common.Data.Entities;
using EmailService.Models;
using System.Linq;

namespace EmailService
{
    public class MailMessageService :IMailMessageService
    {
        private IUnitOfRepository _unitOfRepository;          
        public MailMessageService(IUnitOfRepository unitOfRepository)
        {
            _unitOfRepository = unitOfRepository;            
        }    
        public int AddMailMessage(MailInfo mailInfo)
        {
            var mailMessage = new  Common.Data.Entities.MailMessage();

            mailMessage.MailId = mailInfo.MailId;
            mailMessage.Subject = mailInfo.Subject;
            mailMessage.BodyContent = mailInfo.BodyContent;
            mailMessage.IsAttachment = mailInfo.IsAttachment;
            mailMessage.MailAttachment = (ICollection<MailAttachment>)mailInfo.AttachmentInfos.ToList();

            _unitOfRepository.MailMessageRepository.Add(mailMessage);
            _unitOfRepository.Save();
            return mailInfo.MailId;
        }

        public MailInfo GetMailMessage(int id)
        {              
            MailMessage message = _unitOfRepository.MailMessageRepository.Get(id); 
            MailInfo mailInfo = new MailInfo(message);
            return mailInfo;

            //List<MailAttachment> attachment = _unitOfRepository.MailAttachmentRepository.Find(f => f.Equals(mailInfo.MailId)).ToList();
            //List<AttachmentInfo> attachInfos = null;
            //if (mailInfo.AttachmentInfos.Count > 0)
            //{
            //    attachInfos = new List<AttachmentInfo>();
            //    foreach (var flinfo in mailInfo.AttachmentInfos)
            //    {
            //        attachInfos.Add(flinfo);
            //    }
            //    mailMessage.MailAttachment.Add(attachInfos);
            //}



        }
    }
}
