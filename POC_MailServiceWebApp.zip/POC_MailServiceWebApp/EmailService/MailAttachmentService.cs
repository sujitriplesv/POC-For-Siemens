﻿using Common.Data;
using Common.Data.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using Common.Data.Entities;
using EmailService.Models;
using System.Linq;

namespace EmailService
{
    public class MailAttachmentService : IMailAttachmentService
    {
        private IUnitOfRepository _unitOfRepository;
        public MailAttachmentService(IUnitOfRepository unitOfRepository)
        {
            _unitOfRepository = unitOfRepository;            
        }   
        
        public int AddMailAttachment(AttachmentInfo attachmentInfo)
        {
            var mailattachment = new Common.Data.Entities.MailAttachment();
            mailattachment.MailId = attachmentInfo.MailId;
            mailattachment.AttachmentId = attachmentInfo.AttachmentId;
            mailattachment.FileName = attachmentInfo.FileName;
            _unitOfRepository.MailAttachmentRepository.Add(mailattachment);
            _unitOfRepository.Save();

            return attachmentInfo.AttachmentId;
        }

        public AttachmentInfo GetMailAttachment(int id)
        {              
            MailAttachment mailattachment = _unitOfRepository.MailAttachmentRepository.Get(id); 
            AttachmentInfo attachInfo = new AttachmentInfo(mailattachment);
            return attachInfo;    
        }         
    }
}
