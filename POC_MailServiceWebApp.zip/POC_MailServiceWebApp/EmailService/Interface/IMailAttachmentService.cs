﻿using EmailService.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Data.Interface
{
    public interface IMailAttachmentService
    {
        public int AddMailAttachment(AttachmentInfo attachmentInfo);
        public AttachmentInfo GetMailAttachment(int id);
    }
}
