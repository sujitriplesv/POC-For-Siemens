﻿using EmailService.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Common.Data.Interface
{
    public interface IMailMessageService
    {
        public int AddMailMessage(MailInfo mailMessage);
        public MailInfo GetMailMessage(int id);
    }
}
