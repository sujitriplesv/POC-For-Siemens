﻿using Microsoft.AspNetCore.Http;
using MimeKit;
using System;
using System.Collections.Generic;
using MailKit.Net.Smtp;
using System.Text;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Security;
using MailKit.Search;
using System.IO;
using Common.Data.Interface;
using EmailService.Models;
using System.Linq;
using Common.Data;

namespace EmailService
{
    public class EmailReader :IEmailReader
    {
        private readonly EmailConfiguration _emailConfig;
        private IUnitOfRepository _unitOfRepository;         
        public EmailReader(EmailConfiguration emailConfig, IUnitOfRepository unitOfRepository)
        {
            _emailConfig = emailConfig;
            _unitOfRepository = unitOfRepository;
        }
        public void ReadEmail()
        {             
            Read();             
        }   
        private void Read()
        {
            using (var client = new ImapClient() )                //SmtpClient()
            {
                try
                {
                    client.Connect(_emailConfig.ReadMailBoxAddress, _emailConfig.Port, SecureSocketOptions.SslOnConnect);
                    //client.Connect(_emailConfig.SmtpServer, _emailConfig.Port, true);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    client.Authenticate(_emailConfig.UserName, _emailConfig.Password);
                    
                    if(client.IsConnected)
                    {
                        //FolderAccess inboxAccess = client.Inbox.Open(FolderAccess.ReadWrite);
                        //IMailFolder inboxFolder = client.GetFolder(_emailConfig.AttachmentPath);
                        //IList<UniqueId> uids = client.Inbox.Search(SearchQuery.All);

                        client.Inbox.Open(FolderAccess.ReadWrite);
                        IList<UniqueId> uids = client.Inbox.Search(SearchQuery.All);

                        MailMessageService mailMessage = new MailMessageService(_unitOfRepository);
                        MailInfo mailInfo = new MailInfo();
                        AttachmentInfo attachmentInfo = null;
                        foreach (UniqueId uid in uids)
                        {
                            MimeMessage inboxMessage = client.Inbox.GetMessage(uid);                               

                            foreach (MimeEntity attachment in inboxMessage.Attachments)
                            {
                                var fileName = attachment.ContentDisposition?.FileName ?? attachment.ContentType.Name;

                                attachmentInfo = new AttachmentInfo();
                                //attachmentInfo.MailId = inboxMessage.MessageId;
                                attachmentInfo.FileName = fileName;
                                mailInfo.AttachmentInfos.Add(attachmentInfo);

                                using (var stream = File.Create(fileName))
                                {
                                    if (attachment is MessagePart)
                                    {
                                        var rfc822 = (MessagePart)attachment;

                                        rfc822.Message.WriteTo(stream);
                                    }
                                    else
                                    {
                                        var part = (MimePart)attachment;

                                        part.Content.DecodeTo(stream);
                                    }
                                }

                            }
                            //Save Attachment to FolderPath

                            //Save to Db
                            mailInfo.Subject = inboxMessage.Subject;
                            mailInfo.BodyContent = inboxMessage.Body.ToString();
                            if (inboxMessage.Attachments != null)
                            {
                                mailInfo.IsAttachment = (inboxMessage.Attachments != null && inboxMessage.Attachments.Count() > 0) ? true : false;
                            }

                            mailMessage.AddMailMessage(mailInfo);
                        }

                    }
                    
                }
                catch
                {
                    //log an error message or throw an exception, or both.
                    throw;
                  //ExtendedSocketException: 'A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond. 104.215.148.63:465'

                }
                finally
                {
                    client.Disconnect(true);
                    client.Dispose();
                }
            }
        }           
    }
    
}
